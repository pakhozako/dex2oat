import { MODULE_DIR, STATE_DIR, exec, readText, writeBase64 } from "./bridge.js";
import { countChanged, countEnabled, countHighRiskEnabled, loadJson, loadUserConfig, readGeneratedSystemProp, saveConfig } from "./config.js";
import { readSystemInfo } from "./system-info.js";
import { $, createElement, metric, setStatus, showConfirm } from "./ui.js";
import { shellQuote, resultMessage, parseKeyValueLines, parseStateFile } from "./utils.js";

const state = {
  meta: null,
  options: null,
  config: null,
  device: null,
  configSource: null,
  health: null,
  unifiedState: null,
  page: "home",
  systemInfo: null,
  agreementChallenge: null,
  agreementReadyAt: 0,
  agreementTimer: null
};

const RISK_AGREEMENT_VERSION = 1;
const RISK_WAIT_SECONDS = 30;
const riskModes = {
  safe: {
    label: "安全",
    title: "安全模式",
    description: "优先展示低风险配置，适合日常长期使用。",
    categories: ["safe"]
  },
  caution: {
    label: "谨慎",
    title: "谨慎模式",
    description: "加入高级 ART / dex2oat 调优项，保存前需要确认配置影响。",
    categories: ["safe", "caution"]
  },
  aggressive: {
    label: "危险",
    title: "危险模式",
    description: "展示高风险配置项，可能影响性能、功耗、兼容性或系统稳定性。",
    categories: ["safe", "caution", "aggressive"]
  }
};

function getDiagnosticSections() {
  const staticSections = [
    {
      title: "--- getprop ---",
      props: ["ro.product.model", "ro.build.version.release", "ro.build.version.oplusrom", "ro.oplus.version"]
    },
    {
      title: "--- ART services ---",
      props: ["init.svc.artd", "init.svc.art_boot", "init.svc_debug_pid.artd", "init.svc_debug_pid.art_boot"]
    }
  ];

  const allProps = [];
  if (state.options) {
    const seen = new Set();
    for (const category of state.options.categories) {
      for (const item of category.items) {
        if (item.prop && !seen.has(item.prop)) {
          seen.add(item.prop);
          allProps.push(item.prop);
        }
      }
    }
  }

  return [
    ...staticSections,
    { title: "--- managed props ---", props: allProps }
  ];
}


function buildDiagnosticShell() {
  const lines = [
    "echo '--- bridge ---'",
    "echo shell_ok",
    "GETPROP=/system/bin/getprop",
    "[ -x \"$GETPROP\" ] || GETPROP=getprop"
  ];
  for (const section of getDiagnosticSections()) {
    lines.push(`echo '${section.title.replace(/'/g, "'\"'\"'")}'`);
    for (const prop of section.props) {
      lines.push(`"$GETPROP" ${prop}`);
    }
  }
  return lines.join("\n");
}

function categoryById(id) {
  return state.options.categories.find((category) => category.id === id);
}

function parseModuleProp(content) {
  const result = {};
  for (const entry of parseKeyValueLines(content)) {
    result[entry.prop] = entry.value;
  }
  return result;
}

function commandUrl(value) {
  const url = new URL(String(value || ""));
  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("unsupported URL protocol");
  }

  return shellQuote(url.href);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function loadMeta() {
  const meta = await loadJson("./data/app-meta.json", {
    moduleName: "Dex2oat Lock",
    version: "v3.1",
    githubUrl: ""
  });
  const moduleProp = parseModuleProp(await readText(`${MODULE_DIR}/module.prop`));

  return {
    ...meta,
    moduleName: moduleProp.name || meta.moduleName,
    version: moduleProp.version || meta.version
  };
}

async function loadDeviceState() {
  const unified = state.unifiedState || await loadUnifiedState();
  const device = parseStateFile(await readText(`${STATE_DIR}/device.prop`));
  return {
    ...device,
    "ro.product.model": device["ro.product.model"] || unified["device.model"] || "",
    "ro.product.manufacturer": device["ro.product.manufacturer"] || unified["device.manufacturer"] || "",
    "ro.product.brand": device["ro.product.brand"] || unified["device.brand"] || "",
    "ro.build.version.release": device["ro.build.version.release"] || unified["device.android"] || "",
    schema: device.schema || "rule-driven"
  };
}

async function loadConfigSource() {
  const unified = state.unifiedState || await loadUnifiedState();
  if (unified["config.source"]) {
    return {
      source: unified["config.source"],
      reason: unified["config.reason"],
      updated_at: unified["config.updated_at"],
      matched_total: unified["match.matched_total"] || unified["config.matched_total"] || "0",
      prop_count: unified["config.prop_count"],
      prop_hash: unified["config.prop_hash"],
      version: unified.module_version || state.meta?.version || ""
    };
  }
  return parseStateFile(await readText(`${STATE_DIR}/config-source.prop`));
}

async function loadHealthState() {
  const unified = state.unifiedState || await loadUnifiedState();
  if (unified["health.status"]) {
    return denormalizeState(unified, "health.");
  }
  return parseStateFile(await readText(`${STATE_DIR}/health.log`));
}

async function loadOptionsForDevice(device) {
  return loadJson("./data/options.json", { categories: [] });
}

async function loadUnifiedState() {
  return parseStateFile(await readText(`${STATE_DIR}/state.prop`));
}

function denormalizeState(values, prefix) {
  const result = {};
  for (const [key, value] of Object.entries(values || {})) {
    if (key.startsWith(prefix)) result[key.slice(prefix.length)] = value;
  }
  return result;
}

function renderShell() {
  $("#app").innerHTML = `
    <header class="topbar">
      <div class="brand">
        <span class="brand-logo" aria-hidden="true">D</span>
        <div class="brand-text">
          <h1>${escapeHtml(state.meta.moduleName)}</h1>
          <p>${escapeHtml(state.meta.version)}</p>
        </div>
      </div>
      <div class="top-actions">
        <button class="icon-button" id="refreshButton" title="刷新">↻</button>
        <button class="icon-button" id="rebootButton" title="重启">⏻</button>
      </div>
    </header>
    <main id="page"></main>
    <nav class="bottom-nav">
      <button data-page="home">首页</button>
      <button data-page="custom">自定义</button>
      <button data-page="about">关于</button>
    </nav>
    <div class="status" id="statusMessage" data-tone="neutral">准备就绪</div>
  `;

  $("#refreshButton").addEventListener("click", refreshAll);
  $("#rebootButton").addEventListener("click", rebootDevice);

  document.querySelectorAll(".bottom-nav button").forEach((button) => {
    button.addEventListener("click", () => setPage(button.dataset.page));
  });
}

function setPage(page) {
  state.page = page;
  document.querySelectorAll(".bottom-nav button").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === page);
  });
  renderPage();
}

function renderPage() {
  if (state.page === "home") {
    renderHome();
  } else if (state.page === "custom") {
    renderCustom();
  } else if (state.page === "about") {
    renderAbout();
  } else {
    renderHome();
  }
}

function buildAttentionItems() {
  const items = [];
  const total = Number(state.unifiedState?.["summary.attention_total"] || 0);
  for (let index = 1; index <= total; index += 1) {
    const value = state.unifiedState?.[`summary.attention.${index}`];
    if (value) items.push(value);
  }
  if (!items.length) {
    const conflictTotal = Number(state.unifiedState?.["conflict.total"] || 0);
    const failedTotal = Number(state.unifiedState?.["service.failed_total"] || 0);
    const mismatchTotal = Number(state.unifiedState?.["service.mismatch_total"] || 0);
    if (conflictTotal) items.push(`检测到 ${conflictTotal} 项模块间属性冲突`);
    if (failedTotal || mismatchTotal) items.push(`运行时应用异常：失败 ${failedTotal} 项，未粘住 ${mismatchTotal} 项`);
    if (["warn", "error"].includes(state.health?.status)) items.push(`健康检查状态：${state.health.status}`);
  }
  return items;
}

function currentSummary() {
  const status = state.unifiedState?.["summary.status"] || (buildAttentionItems().length ? "warning" : "pending");
  const labels = {
    ok: "状态正常",
    warning: "存在警告",
    error: "需要处理",
    pending: "待确认",
    recovery: "已恢复"
  };
  return {
    status,
    title: state.unifiedState?.["summary.title"] || labels[status] || "待确认",
    message: state.unifiedState?.["summary.message"] || "正在等待完整状态证据",
    tone: status === "error" ? "is-error" : status === "ok" ? "is-working" : "is-warn"
  };
}

function createStatusCard() {
  const rebootState = state.config.rebootState || {};
  const summary = currentSummary();
  const conflictTotal = Number(state.unifiedState?.["conflict.total"] || 0);
  const hero = createElement("section", `module-status-card ${summary.tone}`);
  hero.innerHTML = `
    <div class="module-status-content">
      <div class="module-status-title">${escapeHtml(summary.title)}</div>
      <div class="module-status-version">${escapeHtml(sourceLabel(state.configSource))}</div>
      <div class="module-status-meta">
        <span>已启用 ${countEnabled(state.config)} 项属性</span>
        <span>最终 prop ${escapeHtml(state.configSource?.prop_count || "0")} 项</span>
        <span>冲突 ${conflictTotal} 项</span>
      </div>
      <div class="module-status-reboot">${escapeHtml(summary.message || rebootState.reason || "状态已汇总到 state.prop")}</div>
    </div>
    <div class="module-status-mark" aria-hidden="true"></div>
  `;
  return hero;
}

function createAttentionSection() {
  const items = buildAttentionItems();
  const section = createSection("需要关注", items.length ? `${items.length} 项` : "无异常置顶");
  section.classList.add(items.length ? "attention-section" : "attention-section", items.length ? "has-items" : "is-empty");
  const list = createElement("div", "attention-list");
  if (!items.length) {
    list.append(createElement("div", "attention-item ok", "当前没有从统一状态中发现需要置顶的问题。"));
  } else {
    for (const item of items) list.append(createElement("div", "attention-item warn", item));
  }
  section.append(list);
  return section;
}

function createSummaryBand() {
  const info = state.systemInfo || {};
  const summary = createElement("section", "summary-band");
  summary.append(metric("设备", state.device?.["ro.product.model"] || "暂不可用"));
  summary.append(metric("规则体系", "规则驱动"));
  summary.append(metric("配置来源", sourceLabel(state.configSource)));
  summary.append(metric("配置摘要", shortHash(state.configSource?.prop_hash)));
  summary.append(metric("系统", state.device?.["ro.build.version.release"] || "暂不可用"));
  summary.append(metric("Root", info.root || "暂不可用"));
  summary.append(metric("最近应用", state.unifiedState?.["service.updated_at"] || state.configSource?.updated_at || "暂不可用"));
  return summary;
}

function shortHash(value) {
  return value ? `${String(value).slice(0, 10)}...` : "暂不可用";
}

function sourceLabel(source) {
  switch (source?.source) {
    case "dex2oat-match":
      return `dex2oat 属性抓取匹配 · ${source.matched_total || 0} 项`;
    case "auto-rules":
      return `自动规则匹配 · ${source.matched_total || 0} 项`;
    case "webui-custom":
      return "WebUI 自定义";
    case "template":
      return "旧模板配置";
    case "template-fallback":
      return "旧模板回退";
    default:
      return "自动规则";
  }
}

function createModuleStateSection() {
  const info = state.systemInfo || {};
  const rebootState = state.config.rebootState || {};
  const label = rebootState.label || (state.config.pendingReboot ? "待重启" : "已生效");
  const moduleState = createSection("运行状态", label);
  const moduleGrid = createElement("div", "metric-grid compact");
  moduleGrid.append(metric("写入异常", `${rebootState.serviceFailedTotal || 0} 失败 / ${rebootState.serviceMismatchTotal || 0} 未粘住`));
  moduleGrid.append(metric("内核", info.kernel || "暂不可用"));
  moduleGrid.append(metric("状态依据", rebootState.reason || "暂不可用"));
  moduleState.append(moduleGrid);
  return moduleState;
}

function createHealthSection() {
  const health = state.health || {};
  const status = health.status || "warn";
  const labels = { ok: "正常", warn: "警告", error: "异常" };
  const section = createSection("健康状态", labels[status] || "警告");
  section.classList.add("health-section", `health-${status}`);
  const grid = createElement("div", "metric-grid compact");
  grid.append(metric("状态", labels[status] || status));
  grid.append(metric("文件", health.files_ok || "unknown"));
  grid.append(metric("属性", health.props_ok || "unknown"));
  grid.append(metric("自愈", health.auto_fixed || "unknown"));
  grid.append(metric("冲突", state.unifiedState?.["conflict.total"] || "0"));
  grid.append(metric("配置哈希", shortHash(state.configSource?.prop_hash)));
  grid.append(metric("完整性", integrityLabel()));
  grid.append(metric("规则匹配", `${state.unifiedState?.["match.matched_total"] || 0} 命中`));
  section.append(grid);
  return section;
}

function integrityLabel() {
  const status = state.unifiedState?.["integrity.status"] || "unknown";
  if (status === "ok") return "通过";
  if (status === "error") return "异常";
  if (status === "warn") return "警告";
  return "未检测";
}

function createLinkRow() {
  const links = createElement("section", "link-row");
  links.append(createButton("查看 system.prop", "wide-button", showSystemProp));
  links.append(createButton("查看诊断", "wide-button", showDiagnostics));
  links.append(createButton("重新抓取匹配", "wide-button", rerunDex2oatMatch));
  links.append(createButton("进入自定义", "wide-button", () => setPage("custom")));
  return links;
}

function renderHome() {
  const page = $("#page");
  page.innerHTML = "";
  page.append(createStatusCard());
  page.append(createAttentionSection());
  page.append(createSummaryBand());
  page.append(createHealthSection());
  page.append(createModuleStateSection());
  page.append(createLinkRow());
}

function createSection(title, meta) {
  const section = createElement("section", "section");
  section.innerHTML = `
    <div class="section-title">
      <h2>${escapeHtml(title)}</h2>
      ${meta ? `<span>${escapeHtml(meta)}</span>` : ""}
    </div>
  `;
  return section;
}

function createButton(text, className, onClick) {
  const button = createElement("button", className, text);
  button.addEventListener("click", onClick);
  return button;
}

function renderCustom() {
  const page = $("#page");
  page.innerHTML = "";

  if (!hasAcceptedCustomAgreement()) {
    page.append(createAgreementGate("custom"));
    return;
  }

  page.append(createRiskModePanel());
  page.append(createSaveSummary());
  page.append(createCustomOptionsList());
  page.append(createSaveActions());
}

function hasAcceptedCustomAgreement() {
  const agreement = state.config.riskAgreement || {};
  return agreement.agreed && agreement.version === RISK_AGREEMENT_VERSION && agreement.customUnlocked;
}

function hasAcceptedAggressiveAgreement() {
  const agreement = state.config.riskAgreement || {};
  return hasAcceptedCustomAgreement() && agreement.aggressiveUnlocked;
}

function createRiskModePanel() {
  const mode = state.config.riskMode || "safe";
  const meta = riskModes[mode] || riskModes.safe;
  const section = createSection("自定义工作台", meta.title);
  section.classList.add("risk-workbench", mode);
  const selector = createElement("div", "risk-mode-row");
  for (const [id, item] of Object.entries(riskModes)) {
    const button = createElement("button", `risk-mode-button ${id === mode ? "active" : ""}`, item.label);
    button.addEventListener("click", () => setRiskMode(id));
    selector.append(button);
  }
  const note = createElement("p", "risk-note", meta.description);
  const status = createElement("div", "risk-status", `协议版本 v${RISK_AGREEMENT_VERSION} · 自定义 ${hasAcceptedCustomAgreement() ? "已解锁" : "未解锁"} · 危险模式 ${hasAcceptedAggressiveAgreement() ? "已解锁" : "未解锁"}`);
  section.append(selector, note, status);
  return section;
}

function setRiskMode(mode) {
  if (mode === "aggressive" && !hasAcceptedAggressiveAgreement()) {
    state.config.riskMode = "caution";
    renderPage();
    showAgreementDialog("aggressive");
    return;
  }
  state.config.riskMode = mode;
  renderPage();
}

function createSaveSummary() {
  const section = createSection("保存摘要", "保存前确认");
  section.classList.add("save-summary");
  const grid = createElement("div", "metric-grid compact");
  grid.append(metric("启用项", countEnabled(state.config)));
  grid.append(metric("变更项", countChanged(state.options, state.config)));
  grid.append(metric("风险模式", riskModes[state.config.riskMode || "safe"].label));
  grid.append(metric("高风险项", countHighRiskEnabled(state.options, state.config)));
  grid.append(metric("配置来源", sourceLabel(state.configSource)));
  grid.append(metric("覆盖自动匹配", state.configSource?.source === "webui-custom" ? "已自定义" : "保存后会覆盖"));
  section.append(grid);
  const hint = createElement("p", "save-hint", "保存会重新生成 system.prop，并更新统一状态；通常需要重启后由 service 完成运行时应用验证。");
  section.append(hint);
  return section;
}

function createCustomOptionsList() {
  const list = createElement("section", "option-list");
  const allowed = new Set(riskModes[state.config.riskMode || "safe"].categories);
  for (const category of state.options.categories.filter((item) => allowed.has(item.id))) {
    const header = createElement("section", `profile-header ${category.tone}`);
    header.innerHTML = `<h2>${escapeHtml(category.title)}</h2><p>${escapeHtml(category.description)}</p>`;
    list.append(header);
    for (const item of category.items) list.append(createOptionRow(category, item));
  }
  return list;
}

function createOptionRow(category, item) {
  const itemState = state.config.items[item.id] || { enabled: item.defaultEnabled, value: item.defaultValue };
  const row = createElement("article", `option-row ${category.tone}`);
  row.innerHTML = `
    <div class="option-copy">
      <h3>${escapeHtml(item.label)}</h3>
      <p>${escapeHtml(item.description)}</p>
      <code>${escapeHtml(item.prop)}</code>
    </div>
    <label class="switch">
      <input type="checkbox" ${itemState.enabled ? "checked" : ""} />
      <span></span>
    </label>
    <select></select>
  `;
  const checkbox = row.querySelector("input");
  const select = row.querySelector("select");
  const safeValue = item.values.includes(itemState.value) ? itemState.value : item.defaultValue;
  for (const value of item.values) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    option.selected = value === safeValue;
    select.append(option);
  }
  checkbox.addEventListener("click", (event) => event.stopPropagation());
  checkbox.addEventListener("change", (event) => {
    event.stopPropagation();
    if (category.id === "aggressive" && checkbox.checked && !hasAcceptedAggressiveAgreement()) {
      checkbox.checked = false;
      showAgreementDialog("aggressive");
      return;
    }
    updateOption(item.id, { enabled: checkbox.checked });
    renderPage();
  });
  select.addEventListener("click", (event) => event.stopPropagation());
  select.addEventListener("change", (event) => {
    event.stopPropagation();
    updateOption(item.id, { value: select.value });
    renderPage();
  });
  row.addEventListener("click", (event) => {
    if (event.target.closest("input, select, label")) return;
    row.classList.toggle("expanded");
  });
  return row;
}

function createSaveActions() {
  const actions = createElement("section", "sticky-actions main-save-actions");
  actions.append(createButton("保存并生成 system.prop", `primary-button ${state.config.riskMode || "safe"}`, saveCurrentConfig));
  return actions;
}

function createAgreementGate(scope) {
  const section = createSection("风险协议", "进入自定义前必须完成");
  section.classList.add("agreement-gate");
  section.append(createElement("p", "risk-note", "首页和诊断可直接查看；自定义配置、危险模式和保存高风险配置需要先完成风险告知确认。"));
  section.append(createButton("阅读并解锁自定义配置", "primary-button", () => showAgreementDialog(scope)));
  return section;
}

function agreementText(scope) {
  const modeText = scope === "aggressive" ? "危险模式" : "自定义配置";
  return [
    `Dex2oat Lock 风险告知与使用确认（v${RISK_AGREEMENT_VERSION}）`,
    "",
    `你正在解锁 ${modeText}。本模块会生成并应用 ART、dexopt、runtime 相关系统属性，这些配置可能改变系统编译、应用安装、后台维护、启动优化和运行时行为。`,
    "自定义配置、规则修改、手动覆盖自动匹配结果或启用危险模式，可能导致性能异常、发热、耗电、应用兼容性问题、系统不稳定、启动异常、卡顿、闪退、功能异常，或与 ROM、Magisk/KernelSU/APatch、内核、其它模块和厂商实现产生冲突。",
    "作者无法验证所有设备、系统版本、ROM、Root 框架、内核和模块组合，也不保证任何自定义配置适用于你的具体环境。你应在理解配置含义和风险后再保存或启用。",
    "如果出现异常，应优先恢复默认配置、重新抓取匹配、禁用冲突模块、重启验证，必要时卸载模块并回滚。自定义配置、危险模式和手动覆盖自动匹配结果造成的后果，由使用者自行评估并承担。"
  ].join("\n");
}

function makeChallenge() {
  const operators = ["+", "-", "*"];
  const op = operators[Math.floor(Math.random() * operators.length)];
  let left = 2 + Math.floor(Math.random() * 8);
  let right = 2 + Math.floor(Math.random() * 8);
  if (op === "-" && right > left) [left, right] = [right, left];
  const answer = op === "+" ? left + right : op === "-" ? left - right : left * right;
  return { prompt: `${left} ${op} ${right} = ?`, answer };
}

function showAgreementDialog(scope = "custom") {
  state.agreementChallenge = makeChallenge();
  state.agreementReadyAt = Date.now() + RISK_WAIT_SECONDS * 1000;
  const dialog = createElement("div", "dialog agreement-dialog");
  dialog.innerHTML = `
    <div class="dialog-panel agreement-panel">
      <div class="section-title">
        <h2>风险协议</h2>
        <div class="dialog-actions"><button class="text-button" data-action="close">关闭</button></div>
      </div>
      <pre>${escapeHtml(agreementText(scope))}</pre>
      <div class="agreement-controls">
        <div class="agreement-countdown" data-countdown></div>
        <label class="challenge-row">计算验证：<strong>${escapeHtml(state.agreementChallenge.prompt)}</strong><input type="number" inputmode="numeric" data-answer /></label>
        <label class="agreement-check"><input type="checkbox" data-agree disabled /> 我已阅读并同意协议</label>
        <button class="primary-button" data-confirm disabled>${scope === "aggressive" ? "解锁危险模式" : "解锁自定义配置"}</button>
      </div>
    </div>
  `;
  const countdown = dialog.querySelector("[data-countdown]");
  const input = dialog.querySelector("[data-answer]");
  const agree = dialog.querySelector("[data-agree]");
  const confirm = dialog.querySelector("[data-confirm]");
  const updateAgreementState = () => {
    const remaining = Math.max(0, Math.ceil((state.agreementReadyAt - Date.now()) / 1000));
    countdown.textContent = remaining ? `请阅读协议，${remaining} 秒后可确认。` : "倒计时已结束，请完成计算验证。";
    const solved = Number(input.value) === state.agreementChallenge.answer;
    agree.disabled = remaining > 0 || !solved;
    confirm.disabled = !agree.checked || agree.disabled;
  };
  input.addEventListener("input", updateAgreementState);
  agree.addEventListener("change", updateAgreementState);
  confirm.addEventListener("click", async () => {
    acceptAgreement(scope);
    await persistWebConfig();
    clearInterval(state.agreementTimer);
    dialog.remove();
    renderPage();
    setStatus(scope === "aggressive" ? "危险模式已解锁" : "自定义配置已解锁", "ok");
  });
  dialog.querySelector('[data-action="close"]').addEventListener("click", () => {
    clearInterval(state.agreementTimer);
    dialog.remove();
  });
  state.agreementTimer = setInterval(updateAgreementState, 500);
  updateAgreementState();
  document.body.append(dialog);
}

function acceptAgreement(scope) {
  const now = formatTimestamp(new Date());
  state.config.riskAgreement = {
    ...(state.config.riskAgreement || {}),
    version: RISK_AGREEMENT_VERSION,
    agreed: true,
    agreedAt: now,
    customUnlocked: true,
    aggressiveUnlocked: scope === "aggressive" ? true : Boolean(state.config.riskAgreement?.aggressiveUnlocked)
  };
  if (scope === "aggressive") state.config.riskMode = "aggressive";
}

async function persistWebConfig() {
  const config = { ...state.config };
  delete config.rebootState;
  await writeBase64(`${STATE_DIR}/config.json`, JSON.stringify(config, null, 2) + "\n");
  await writeBase64(`${STATE_DIR}/state.prop`, serializeMergedState({
    ...(state.unifiedState || {}),
    "risk.mode": state.config.riskMode || "safe",
    "risk.agreement_version": String(RISK_AGREEMENT_VERSION),
    "risk.agreed_at": state.config.riskAgreement?.agreedAt || "",
    "risk.custom_unlocked": state.config.riskAgreement?.customUnlocked ? "yes" : "no",
    "risk.aggressive_unlocked": state.config.riskAgreement?.aggressiveUnlocked ? "yes" : "no"
  }));
  state.unifiedState = await loadUnifiedState();
}

function serializeMergedState(values) {
  return Object.entries(values || {}).map(([key, value]) => `${key}=${value ?? ""}`).join("\n") + "\n";
}

function renderAbout() {
  const page = $("#page");
  page.innerHTML = "";
  const about = createSection("关于", state.meta.version);
  const grid = createElement("div", "metric-grid compact");
  grid.append(metric("模块", state.meta.moduleName));
  grid.append(metric("版本", state.meta.version));
  grid.append(metric("架构", "规则驱动 / 统一状态"));
  grid.append(metric("协议", hasAcceptedCustomAgreement() ? "已同意" : "未同意"));
  grid.append(metric("完整性", integrityLabel()));
  grid.append(metric("状态源", "state.prop"));
  about.append(grid);
  const actions = createElement("section", "link-row");
  actions.append(createButton("打开 GitHub", "wide-button", () => openUrl(state.meta.githubUrl)));
  actions.append(createButton("查看诊断", "wide-button", showDiagnostics));
  actions.append(createButton("查看 system.prop", "wide-button", showSystemProp));
  actions.append(createButton("查看风险协议", "wide-button", () => showAgreementDialog("custom")));
  page.append(about, actions);
}

function renderCategory(categoryId) {
  const category = categoryById(categoryId);
  const page = $("#page");
  page.innerHTML = "";
  if (!category) {
    page.append(createSection("配置不可用", "options 文件为空或损坏"));
    return;
  }

  const header = createElement("section", `profile-header ${category.tone}`);
  header.innerHTML = `<h2>${escapeHtml(category.title)}</h2><p>${escapeHtml(category.description)}</p>`;
  page.append(header);

  const list = createElement("section", "option-list");

  for (const item of category.items) {
    const itemState = state.config.items[item.id] || { enabled: item.defaultEnabled, value: item.defaultValue };
    const row = createElement("article", "option-row");
    row.innerHTML = `
      <div class="option-copy">
        <h3>${escapeHtml(item.label)}</h3>
        <p>${escapeHtml(item.description)}</p>
        <code>${escapeHtml(item.prop)}</code>
      </div>
      <label class="switch">
        <input type="checkbox" ${itemState.enabled ? "checked" : ""} />
        <span></span>
      </label>
      <select></select>
    `;

    const checkbox = row.querySelector("input");
    const select = row.querySelector("select");

    const safeValue = item.values.includes(itemState.value) ? itemState.value : item.defaultValue;
    for (const value of item.values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      option.selected = value === safeValue;
      select.append(option);
    }

    checkbox.addEventListener("click", (event) => {
      event.stopPropagation();
    });

    checkbox.addEventListener("change", (event) => {
      event.stopPropagation();
      if (categoryId === "aggressive" && checkbox.checked) {
        const ok = showConfirm("危险选项可能影响性能、兼容性、安装耗时或 OTA 后维护流程。确定启用吗？");
        if (!ok) {
          checkbox.checked = false;
          return;
        }
      }
      updateOption(item.id, { enabled: checkbox.checked });
    });

    select.addEventListener("click", (event) => {
      event.stopPropagation();
    });

    select.addEventListener("change", (event) => {
      event.stopPropagation();
      updateOption(item.id, { value: select.value });
    });

    row.addEventListener("click", (e) => {
      if (e.target.closest("input, select")) return;
      row.classList.toggle("expanded");
    });

    list.append(row);
  }

  page.append(list);

  const actions = createElement("section", "sticky-actions");
  actions.append(createButton("保存并生成 system.prop", `primary-button ${category.tone}`, saveCurrentConfig));
  page.append(actions);
}

function updateOption(id, patch) {
  if (patch.enabled) {
    const current = state.options.categories.flatMap((category) => category.items).find((item) => item.id === id);
    if (current && current.prop) {
      for (const category of state.options.categories) {
        for (const item of category.items) {
          if (item.id !== id && item.prop === current.prop && state.config.items[item.id]) {
            state.config.items[item.id].enabled = false;
          }
        }
      }
    }
  }

  state.config.items[id] = {
    ...state.config.items[id],
    ...patch
  };
}

async function refreshAll() {
  setStatus("正在刷新设备信息...");
  try {
    state.unifiedState = await loadUnifiedState();
    state.device = await loadDeviceState();
    state.systemInfo = await readSystemInfo();
    state.health = await loadHealthState();
    state.configSource = await loadConfigSource();
    state.config = await loadUserConfig(state.options);
    renderPage();
    setStatus("设备信息已刷新", "ok");
  } catch (error) {
    setStatus(`刷新失败：${error.message}`, "warn");
  }
}

async function refreshSystemInfo() {
  state.systemInfo = await readSystemInfo();
}

async function saveCurrentConfig() {
  if (!hasAcceptedCustomAgreement()) {
    showAgreementDialog("custom");
    return;
  }
  if ((state.config.riskMode === "aggressive" || countHighRiskEnabled(state.options, state.config) > 0) && !hasAcceptedAggressiveAgreement()) {
    showAgreementDialog("aggressive");
    return;
  }
  const highRiskCount = countHighRiskEnabled(state.options, state.config);
  if (highRiskCount > 0 && !showConfirm(`当前启用了 ${highRiskCount} 项高风险配置。保存会生成新的 system.prop，通常需要重启后验证。确定继续吗？`)) {
    return;
  }
  setStatus("正在保存配置...");
  const nextConfig = {
    ...state.config,
    profile: state.config.riskMode || "safe"
  };
  try {
    state.config = await saveConfig(state.options, nextConfig);
    state.unifiedState = await loadUnifiedState();
    state.configSource = await loadConfigSource();
    renderPage();
    setStatus("已保存，重启后生效", "warn");
  } catch (error) {
    setStatus(`保存失败：${error.message}`, "warn");
  }
}

async function showSystemProp() {
  const content = await readGeneratedSystemProp();
  showDialog("system.prop", content || "暂不可用");
}

async function rerunDex2oatMatch() {
  const ok = showConfirm("重新抓取匹配将在后台触发 service 执行，完成后需要重启生效。确定继续吗？");
  if (!ok) return;

  setStatus("已写入触发文件，等待 service 处理...");
  await writeBase64(`${STATE_DIR}/trigger-rematch`, `requested_at=${formatTimestamp(new Date())}\n`);
  await exec(`sh ${shellQuote(`${MODULE_DIR}/service.sh`)} >/dev/null 2>&1 &`);

  let completed = false;
  for (let i = 0; i < 45; i += 1) {
    await delay(2000);
    const trigger = await readText(`${STATE_DIR}/trigger-rematch`);
    if (!trigger) {
      completed = true;
      break;
    }
  }

  await refreshAll();
  setStatus(completed ? "重新匹配完成，重启后生效" : "重新匹配仍在后台执行，请稍后查看诊断", "warn");
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatTimestamp(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

async function renderHistory() {
  const page = $("#page");
  page.innerHTML = "";
  const section = createSection("安装历史", "install.log");
  const content = createElement("div", "history-log", "正在读取...");
  section.append(content);
  page.append(section);

  const log = await readText(`${STATE_DIR}/install.log`);
  const entries = parseInstallLog(log || "");
  content.innerHTML = "";
  if (!entries.length) {
    content.textContent = "暂无安装历史";
    return;
  }
  for (const entry of entries) {
    const card = createElement("div", "history-card");
    card.append(metric("时间", entry.time || "未知"));
    card.append(metric("规则", "规则驱动"));
    card.append(metric("来源", sourceLabel({ source: entry.source, matched_total: entry.matched_total })));
    card.append(metric("匹配数量", entry.matched_total || "0"));
    card.append(metric("版本", entry.version || "未知"));
    content.append(card);
  }
}

function parseInstallLog(content) {
  const entries = [];
  let current = null;
  for (const line of content.split(/\r?\n/)) {
    if (line.trim() === "--- install ---") {
      if (current) entries.push(current);
      current = {};
      continue;
    }
    if (!current) continue;
    const index = line.indexOf("=");
    if (index > 0) current[line.slice(0, index)] = line.slice(index + 1);
  }
  if (current) entries.push(current);
  return entries.reverse();
}


function buildStaticDiagnosticShell() {
  return [
    "echo '--- meminfo ---'",
    "cat /proc/meminfo | head -n 8",
    "echo '--- battery ---'",
    "ls -l /sys/class/power_supply/battery 2>/dev/null",
    "cat /sys/class/power_supply/battery/capacity 2>/dev/null",
    "cat /sys/class/power_supply/battery/status 2>/dev/null",
    "cat /sys/class/power_supply/battery/temp 2>/dev/null",
    "echo '--- storage ---'",
    "df -k /data 2>/dev/null",
    "echo '--- install state ---'",
    "cat /data/adb/dex2oat-lock-install.prop 2>/dev/null",
    "echo '--- unified state ---'",
    "cat /data/adb/dex2oat-lock/state.prop 2>/dev/null",
    "echo '--- device state ---'",
    "cat /data/adb/dex2oat-lock/device.prop 2>/dev/null",
    "echo '--- current system.prop ---'",
    "cat /data/adb/modules/dex2oat-lock/system.prop 2>/dev/null",
    "echo '--- config source ---'",
    "cat /data/adb/dex2oat-lock/config-source.prop 2>/dev/null",
    "echo '--- dex2oat match report ---'",
    "cat /data/adb/dex2oat-lock/match-report.txt 2>/dev/null",
    "echo '--- captured props ---'",
    "cat /data/adb/dex2oat-lock/captured-props.txt 2>/dev/null",
    "echo '--- reboot state ---'",
    "cat /proc/sys/kernel/random/boot_id 2>/dev/null",
    "cat /data/adb/dex2oat-lock/service-state.prop 2>/dev/null",
    "echo '--- health log ---'",
    "cat /data/adb/dex2oat-lock/health.log 2>/dev/null",
    "echo '--- conflict report ---'",
    "cat /data/adb/dex2oat-lock/conflict-report.txt 2>/dev/null",
    "echo '--- integrity report ---'",
    "cat /data/adb/dex2oat-lock/integrity-report.txt 2>/dev/null",
    "echo '--- uninstall state ---'",
    "cat /data/adb/dex2oat-lock-uninstall.prop 2>/dev/null",
    "echo '--- apply log ---'",
    "tail -n 120 /data/adb/dex2oat-lock/service.log 2>/dev/null || true"
  ].join("\n");
}

async function showDiagnostics() {
  setStatus("正在读取诊断输出...");
  const dynamicPart = buildDiagnosticShell();
  const staticPart = buildStaticDiagnosticShell();
  const result = await exec(`${dynamicPart}\n${staticPart}`);

  await showDiagnosticsDialog(`errno=${result.code}\n\n${result.stdout || ""}\n${result.stderr || ""}`);
  setStatus(result.code === 0 ? "诊断输出已生成" : `诊断命令异常：${resultMessage(result)}`, result.code === 0 ? "ok" : "warn");
}

function parseApplyLog(content) {
  const groups = {
    failed: [],
    mismatch: [],
    applied: [],
    matched: []
  };
  const passSummaries = [];
  let summary = "";
  const pattern = /\b(Applied|Matched|Mismatch|Failed): (?:phase=([^ ]+) )?key=([^ ]+) desired=([^ ]*) old=([^ ]*) new=([^ ]*) tool=([^ ]*) code=([0-9]+)/;
  const passPattern = /Runtime property apply pass completed: phase=([^ ]+) total=([0-9]+) applied=([0-9]+) matched=([0-9]+) mismatch=([0-9]+) failed=([0-9]+)/;

  for (const line of content.split(/\r?\n/)) {
    if (line.includes("Runtime property apply completed.")) {
      summary = line;
      continue;
    }

    const pass = line.match(passPattern);
    if (pass) {
      passSummaries.push({
        phase: pass[1],
        total: Number(pass[2]),
        applied: Number(pass[3]),
        matched: Number(pass[4]),
        mismatch: Number(pass[5]),
        failed: Number(pass[6])
      });
      continue;
    }

    const match = line.match(pattern);
    if (!match) continue;

    const entry = {
      status: match[1].toLowerCase(),
      phase: match[2] || "",
      prop: match[3],
      desired: match[4],
      oldValue: match[5],
      newValue: match[6],
      tool: match[7],
      code: match[8]
    };

    groups[entry.status].push(entry);
  }

  return { groups, passSummaries, summary };
}

function parseActiveSystemProp(content) {
  const props = {};
  for (const entry of parseKeyValueLines(content)) {
    props[entry.prop] = entry.value;
  }
  return props;
}

function parseDiagnosticGetprop(content) {
  const props = {};
  const sectionByTitle = new Map(getDiagnosticSections().map((section) => [section.title, section]));
  let activeSection = null;
  let activeIndex = 0;

  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();

    if (sectionByTitle.has(trimmed)) {
      activeSection = sectionByTitle.get(trimmed);
      activeIndex = 0;
      continue;
    }

    if (trimmed.startsWith("--- ")) {
      activeSection = null;
      activeIndex = 0;
      continue;
    }

    if (!activeSection || activeIndex >= activeSection.props.length) continue;
    props[activeSection.props[activeIndex]] = trimmed;
    activeIndex += 1;
  }

  return props;
}

function parseDiagnosticRebootState(content) {
  const lines = [];
  let bootId = "";
  let inSection = false;

  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed === "--- reboot state ---") {
      inSection = true;
      continue;
    }
    if (inSection && trimmed.startsWith("--- ")) break;
    if (!inSection) continue;
    if (!trimmed) continue;

    if (!trimmed.includes("=") && !bootId) {
      bootId = trimmed;
      continue;
    }

    lines.push(line);
  }

  const state = parseStateFile(lines.join("\n"));

  return {
    bootId,
    status: state.status || "",
    phase: state.phase || "",
    health: state.health || "",
    reason: state.reason || "",
    updatedAt: Number(state.updated_at || 0),
    settledAt: Number(state.settled_at || 0),
    serviceBootId: state.boot_id || "",
    phaseTotal: Number(state.phase_total || 0),
    phaseApplied: Number(state.phase_applied || 0),
    phaseMatched: Number(state.phase_matched || 0),
    phaseMismatch: Number(state.phase_mismatch || 0),
    phaseFailed: Number(state.phase_failed || 0),
    propTotal: Number(state.prop_total || 0),
    appliedTotal: Number(state.applied_total || 0),
    matchedTotal: Number(state.matched_total || 0),
    mismatchTotal: Number(state.mismatch_total || 0),
    failedTotal: Number(state.failed_total || 0)
  };
}

function parseDiagnosticSection(content, title) {
  const sectionLines = [];
  let inSection = false;

  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed === title) {
      inSection = true;
      continue;
    }
    if (inSection && trimmed.startsWith("--- ")) break;
    if (inSection) sectionLines.push(line);
  }

  return parseStateFile(sectionLines.join("\n"));
}

function latestApplyByProp(groups) {
  const result = new Map();

  for (const entry of [...groups.applied, ...groups.matched, ...groups.mismatch, ...groups.failed]) {
    result.set(entry.prop, entry);
  }

  return result;
}

function buildDiagnosticState(content, applyLog, desiredProps) {
  const actualProps = parseDiagnosticGetprop(content);
  const latestByProp = latestApplyByProp(applyLog.groups);
  const mismatches = [];
  const missing = [];

  for (const [prop, expected] of Object.entries(desiredProps)) {
    if (!Object.prototype.hasOwnProperty.call(actualProps, prop)) {
      missing.push({ prop, expected });
    } else if (actualProps[prop] !== expected) {
      const latest = latestByProp.get(prop);
      mismatches.push({ prop, expected, actual: actualProps[prop], latest });
    }
  }

  const postApplyOverrides = mismatches.filter(({ expected, latest }) =>
    latest && ["applied", "matched"].includes(latest.status) && latest.newValue === expected
  );
  const unresolved = mismatches.filter(({ expected, latest }) =>
    !latest || ["mismatch", "failed"].includes(latest.status) || latest.newValue !== expected
  );

  return {
    actualProps,
    desiredProps,
    mismatches,
    missing,
    matchedCount: Math.max(Object.keys(desiredProps).length - mismatches.length - missing.length, 0),
    postApplyOverrides,
    unresolved
  };
}

async function showDiagnosticsDialog(content) {
  const applyLog = parseApplyLog(content);
  const installState = parseDiagnosticSection(content, "--- install state ---");
  const rebootState = parseDiagnosticRebootState(content);
  const uninstallState = parseDiagnosticSection(content, "--- uninstall state ---");
  const desiredProps = parseActiveSystemProp(await readGeneratedSystemProp());
  const originalPropsContent = await readText(`${STATE_DIR}/original-props.conf`);
  const currentSystemProp = await readGeneratedSystemProp();
  const diagnosticState = buildDiagnosticState(content, applyLog, desiredProps);
  const healthState = parseDiagnosticSection(content, "--- health log ---");
  const conflictState = parseDiagnosticSection(content, "--- conflict report ---");
  const unifiedState = parseDiagnosticSection(content, "--- unified state ---");
  const integrityState = parseDiagnosticSection(content, "--- integrity report ---");
  showDialog("诊断输出", content, createDiagnosticSummary(applyLog, diagnosticState, rebootState, installState, uninstallState, originalPropsContent, currentSystemProp, healthState, conflictState, unifiedState, integrityState), {
    copyLabel: "复制全部诊断信息",
    savePath: `${STATE_DIR}/logs/webui-diagnostic.txt`
  });
}

function createDiagnosticSummary(applyLog, diagnosticState, rebootState, installState, uninstallState, originalPropsContent, currentSystemProp, healthState, conflictState, unifiedState, integrityState) {
  const section = createElement("section", "diagnostic-stack");
  section.append(createUnifiedStateSummary(unifiedState));
  section.append(createRuleMatchSummary(unifiedState));
  section.append(createConfigGenerationSummary(unifiedState));
  section.append(createIntegritySummary(integrityState, unifiedState));
  section.append(createConflictBanner(conflictState));
  section.append(createHealthLogSummary(healthState, conflictState));
  section.append(createLifecycleStateSummary(installState, uninstallState));
  section.append(createRebootStateSummary(rebootState, applyLog.passSummaries));
  section.append(createPropCompareSection(originalPropsContent, currentSystemProp));
  section.append(createFinalPropSummary(diagnosticState));
  section.append(createApplyLogSummary(applyLog, diagnosticState, rebootState));
  return section;
}

function createUnifiedStateSummary(unifiedState) {
  const status = unifiedState["summary.status"] || "unknown";
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "统一状态结论"));
  header.append(createElement("span", "", unifiedState["summary.message"] || "未读取到 state.prop 摘要"));
  section.append(header);
  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("状态", status, status === "ok" ? "applied" : status === "error" ? "failed" : "mismatch"));
  chips.append(createDiagnosticChip("关注项", unifiedState["summary.attention_total"] || 0, Number(unifiedState["summary.attention_total"] || 0) ? "mismatch" : "applied"));
  chips.append(createDiagnosticChip("配置", unifiedState["config.source"] || "unknown", unifiedState["config.source"] ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("风险", unifiedState["risk.mode"] || "safe", unifiedState["risk.mode"] === "aggressive" ? "failed" : "applied"));
  section.append(chips);
  const attention = createElement("div", "diagnostic-problems");
  const total = Number(unifiedState["summary.attention_total"] || 0);
  for (let index = 1; index <= total; index += 1) {
    const text = unifiedState[`summary.attention.${index}`];
    if (text) attention.append(createElement("div", "diagnostic-problem mismatch", text));
  }
  if (total) section.append(attention);
  return section;
}

function createRuleMatchSummary(unifiedState) {
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "规则匹配"));
  header.append(createElement("span", "", `mode=${unifiedState["match.mode"] || "unknown"} updated=${unifiedState["match.updated_at"] || "unknown"}`));
  section.append(header);
  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("匹配状态", unifiedState["match.status"] || "unknown", unifiedState["match.status"] === "ok" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("抓取", unifiedState["match.captured_total"] || 0, "applied"));
  chips.append(createDiagnosticChip("命中", unifiedState["match.matched_total"] || 0, "applied"));
  chips.append(createDiagnosticChip("默认", unifiedState["match.default_total"] || 0, "matched"));
  section.append(chips);
  return section;
}

function createConfigGenerationSummary(unifiedState) {
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "配置生成"));
  header.append(createElement("span", "", `source=${unifiedState["config.source"] || "unknown"} hash=${shortHash(unifiedState["config.prop_hash"])}`));
  section.append(header);
  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("生成状态", unifiedState["config.status"] || "unknown", unifiedState["config.status"] === "ok" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("prop 数", unifiedState["config.prop_count"] || 0, "applied"));
  chips.append(createDiagnosticChip("来源", unifiedState["config.source"] || "unknown", "matched"));
  chips.append(createDiagnosticChip("更新时间", unifiedState["config.updated_at"] || "unknown", "applied"));
  section.append(chips);
  return section;
}

function createIntegritySummary(integrityState, unifiedState) {
  const status = integrityState.status || unifiedState["integrity.status"] || "unknown";
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "完整性 / 防篡改"));
  header.append(createElement("span", "", `reason=${integrityState.reason || unifiedState["integrity.reason"] || "unknown"}`));
  section.append(header);
  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("状态", status, status === "ok" ? "applied" : status === "error" ? "failed" : "mismatch"));
  chips.append(createDiagnosticChip("检查", integrityState.checked_total || unifiedState["integrity.checked_total"] || 0, "applied"));
  chips.append(createDiagnosticChip("缺失", integrityState.missing_total || unifiedState["integrity.missing_total"] || 0, Number(integrityState.missing_total || unifiedState["integrity.missing_total"] || 0) ? "failed" : "applied"));
  chips.append(createDiagnosticChip("变更", integrityState.changed_total || unifiedState["integrity.changed_total"] || 0, Number(integrityState.changed_total || unifiedState["integrity.changed_total"] || 0) ? "failed" : "applied"));
  section.append(chips);
  return section;
}

function createConflictBanner(conflictState) {
  const total = Number(conflictState.conflict_total || 0);
  const banner = createElement("div", `diagnostic-conflict-banner ${total > 0 ? "show" : "hide"}`);
  banner.textContent = total > 0 ? `检测到 ${total} 项属性冲突，请查看 conflict-report.txt` : "";
  return banner;
}

function createHealthLogSummary(healthState, conflictState) {
  const status = healthState.status || "unknown";
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "自愈监控"));
  header.append(createElement("span", "", `health=${status} conflict=${conflictState.conflict_total || 0}`));
  section.append(header);
  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("健康", status, status === "ok" ? "applied" : status === "error" ? "failed" : "mismatch"));
  chips.append(createDiagnosticChip("文件", healthState.files_ok || "unknown", healthState.files_ok === "yes" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("属性", healthState.props_ok || "unknown", healthState.props_ok === "yes" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("冲突", conflictState.conflict_total || 0, Number(conflictState.conflict_total || 0) > 0 ? "failed" : "applied"));
  section.append(chips);
  return section;
}

function createPropCompareSection(originalContent, systemContent) {
  const original = parseOriginalProps(originalContent || "");
  const current = parseActiveSystemProp(systemContent || "");
  const keys = [...new Set([...Object.keys(original), ...Object.keys(current)])].sort();
  const changed = keys.filter((key) => (original[key] || "<unset>") !== (current[key] || "<unset>"));
  const details = createElement("details", "diagnostic-summary prop-compare");
  details.open = false;
  const summary = createElement("summary", "diagnostic-summary-head");
  summary.append(createElement("strong", "", "属性上下对比"));
  summary.append(createElement("span", "", `${changed.length} 项差异，可展开查看 original-props.conf 与当前 system.prop`));
  details.append(summary);

  const originalBlock = createElement("pre", "prop-compare-block", originalContent || "original-props.conf 暂无内容");
  const currentBlock = createElement("pre", "prop-compare-block", systemContent || "system.prop 暂无内容");
  details.append(createElement("strong", "", "original-props.conf（安装前原始值）"));
  details.append(originalBlock);
  details.append(createElement("strong", "", "当前 system.prop（模块生成值）"));
  details.append(currentBlock);

  const list = createElement("div", "diagnostic-problems");
  for (const key of changed.slice(0, 120)) {
    const item = createElement("div", "diagnostic-problem mismatch");
    item.append(createElement("strong", "", key));
    item.append(createElement("span", "", `${original[key] || "<unset>"} -> ${current[key] || "<unset>"}`));
    list.append(item);
  }
  details.append(list);
  return details;
}

function parseOriginalProps(content) {
  const props = {};
  for (const line of content.split(/\r?\n/)) {
    if (!line || line.startsWith("#")) continue;
    if (line.startsWith("@unset:")) {
      props[line.slice(7)] = "<unset>";
    } else {
      const index = line.indexOf("=");
      if (index > 0) props[line.slice(0, index)] = line.slice(index + 1);
    }
  }
  return props;
}

function createLifecycleStateSummary(installState, uninstallState) {
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  const installStatus = installState.status || "未知";
  const uninstallStatus = uninstallState.status || "未记录";
  header.append(createElement("strong", "", "安装/卸载状态"));
  header.append(createElement("span", "", buildLifecycleDiagnosticText(installState, uninstallState)));
  section.append(header);

  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("安装", installStatus, installStatus === "ok" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("备份", installState.backup_ready || "未知", installState.backup_ready === "1" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("卸载", uninstallStatus, uninstallStatus === "ok" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("卸载失败", uninstallState.failed || "0", Number(uninstallState.failed || 0) ? "failed" : "applied"));
  section.append(chips);

  return section;
}

function buildLifecycleDiagnosticText(installState, uninstallState) {
  if (installState.status === "failed") {
    return `安装状态文件报告失败：${installState.reason || "未记录原因"}。`;
  }

  if (installState.status === "ok" && uninstallState.status === "ok") {
    return "安装和卸载状态都记录为 ok；若模块仍显示异常，请回传完整日志。";
  }

  if (installState.status === "ok") {
    return "安装状态已记录为 ok；未记录卸载状态属于正常运行中的模块。";
  }

  if (uninstallState.status) {
    return `已读取卸载状态：${uninstallState.status}，failed=${uninstallState.failed || 0}。`;
  }

  return "未读取到安装状态文件；请确认刷入包为最新构建并回传 install.log。";
}

function createRebootStateSummary(rebootState, passSummaries) {
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "重启状态"));
  header.append(createElement("span", "", buildRebootDiagnosticText(rebootState, passSummaries)));
  section.append(header);

  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("服务", rebootState.status || "未知", rebootState.status === "settled" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("健康", rebootState.health || "未知", rebootState.health === "problem" ? "failed" : "applied"));
  chips.append(createDiagnosticChip("阶段", rebootState.phase || "未知", rebootState.phase === "settled" ? "applied" : "mismatch"));
  chips.append(createDiagnosticChip("异常", `${rebootState.failedTotal || 0}/${rebootState.mismatchTotal || 0}`, rebootState.failedTotal || rebootState.mismatchTotal ? "failed" : "applied"));
  chips.append(createDiagnosticChip("settled", rebootState.settledAt ? "已记录" : "缺失", rebootState.settledAt ? "applied" : "mismatch"));
  section.append(chips);

  return section;
}

function buildRebootDiagnosticText(rebootState, passSummaries) {
  const hasSettledPass = passSummaries.some((pass) => pass.phase === "settled");
  const problemTotal = (rebootState.failedTotal || 0) + (rebootState.mismatchTotal || 0);

  if (rebootState.status === "error" || rebootState.health === "problem") {
    return rebootState.reason
      ? `服务异常：${rebootState.reason}。`
      : "服务状态为异常；请检查 apply.log 与模块文件是否完整。";
  }

  if (rebootState.status === "skipped" || rebootState.health === "skipped") {
    return rebootState.reason
      ? `服务已跳过：${rebootState.reason}。`
      : "服务已跳过运行时属性应用；设备可能未匹配到可应用的运行时属性。";
  }

  if (problemTotal) {
    return `服务状态已记录 ${problemTotal} 项写入异常；请优先检查 apply.log 的 Failed/Mismatch。`;
  }

  if (rebootState.status === "settled" && rebootState.settledAt && hasSettledPass) {
    return "服务已完成 settled，若首页仍显示待重启，优先检查 config.json 的 pendingSavedAt 或管理器缓存。";
  }

  if (!rebootState.bootId && rebootState.status !== "settled") {
    return "未读到 boot_id，且服务未记录 settled；状态仍待重启是合理的。";
  }

  if (rebootState.status === "settled" && !rebootState.settledAt) {
    return "服务状态为 settled，但缺少 settled_at；建议重新刷入当前包后重启。";
  }

  if (!hasSettledPass) {
    return "apply.log 没有 settled 阶段；开机后需至少等待 3 分钟再判断。";
  }

  return "重启状态证据不完整；请回传完整诊断文本和 apply.log。";
}

function createFinalPropSummary(diagnosticState) {
  const section = createElement("section", "diagnostic-summary");
  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "最终属性"));
  header.append(createElement("span", "", buildFinalPropDiagnosticText(diagnosticState)));
  section.append(header);

  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("匹配", diagnosticState.matchedCount, "applied"));
  chips.append(createDiagnosticChip("后置覆盖", diagnosticState.postApplyOverrides.length, diagnosticState.postApplyOverrides.length ? "mismatch" : "applied"));
  chips.append(createDiagnosticChip("未解决", diagnosticState.unresolved.length, diagnosticState.unresolved.length ? "failed" : "applied"));
  chips.append(createDiagnosticChip("缺失", diagnosticState.missing.length, diagnosticState.missing.length ? "mismatch" : "applied"));
  section.append(chips);

  return section;
}

function buildFinalPropDiagnosticText(diagnosticState) {
  if (diagnosticState.unresolved.length || diagnosticState.missing.length) {
    return `${diagnosticState.unresolved.length + diagnosticState.missing.length} 项最终 getprop 仍未证明生效，需要结合完整 apply.log 继续查。`;
  }

  if (diagnosticState.postApplyOverrides.length) {
    return `${diagnosticState.postApplyOverrides.length} 项已由模块写入，但之后被系统改回；这是 ColorOS 后置覆盖，不等同于刷入失败。`;
  }

  return "最终 getprop 与当前 system.prop 启用项一致。";
}

function createApplyLogSummary({ groups, passSummaries, summary }, diagnosticState, rebootState) {
  const total = Object.values(groups).reduce((count, rows) => count + rows.length, 0);
  const section = createElement("section", "diagnostic-summary");

  const header = createElement("div", "diagnostic-summary-head");
  header.append(createElement("strong", "", "apply.log 摘要"));
  header.append(createElement("span", "", summary || (total ? `${total} 条记录` : "未读取到 apply.log 摘要")));
  section.append(header);
  section.append(createDiagnosticConclusion(groups, passSummaries, total, summary, diagnosticState, rebootState));

  const chips = createElement("div", "diagnostic-chip-row");
  chips.append(createDiagnosticChip("失败", groups.failed.length, "failed"));
  chips.append(createDiagnosticChip("未粘住", groups.mismatch.length, "mismatch"));
  chips.append(createDiagnosticChip("已应用", groups.applied.length, "applied"));
  chips.append(createDiagnosticChip("已匹配", groups.matched.length, "matched"));
  section.append(chips);

  const problems = [...groups.failed, ...groups.mismatch].slice(0, 8);
  if (problems.length) {
    const list = createElement("div", "diagnostic-problems");
    for (const entry of problems) {
      const item = createElement("div", `diagnostic-problem ${entry.status}`);
      item.append(createElement("strong", "", entry.prop));
      item.append(createElement("span", "", `${entry.status}${entry.phase ? ` · phase=${entry.phase}` : ""} · desired=${entry.desired} · new=${entry.newValue || "<empty>"} · ${entry.tool}`));
      list.append(item);
    }
    section.append(list);
  }

  const finalProblems = [...diagnosticState.postApplyOverrides, ...diagnosticState.unresolved, ...diagnosticState.missing].slice(0, 8);
  if (finalProblems.length) {
    const list = createElement("div", "diagnostic-problems");
    for (const entry of finalProblems) {
      const item = createElement("div", "diagnostic-problem mismatch");
      item.append(createElement("strong", "", entry.prop));
      item.append(createElement("span", "", `expected=${entry.expected} 路 final=${entry.actual || "<missing>"}`));
      list.append(item);
    }
    section.append(list);
  }

  return section;
}

function createDiagnosticConclusion(groups, passSummaries, total, summary, diagnosticState, rebootState) {
  const failed = groups.failed.length;
  const mismatch = groups.mismatch.length;
  const hasSettled = passSummaries.some((pass) => pass.phase === "settled");
  const latestPass = passSummaries[passSummaries.length - 1];
  const conclusion = createElement("div", "diagnostic-conclusion");
  let tone = "mismatch";
  let title = "status=not-applied";
  let detail = "没有读取到 apply.log 记录，暂时不能证明模块服务已在开机后运行。";

  if (rebootState.status === "error") {
    tone = "failed";
    title = "status=service-error";
    detail = rebootState.reason
      ? `service-state 报告服务异常：${rebootState.reason}。`
      : "service-state 报告服务异常；请检查模块文件和 apply.log。";
  } else if (rebootState.status === "skipped") {
    tone = "mismatch";
    title = "status=service-skipped";
    detail = rebootState.reason
      ? `service-state 报告已跳过运行时应用：${rebootState.reason}。`
        : "service-state 报告已跳过运行时应用；设备可能未匹配到可应用的运行时属性。";
  } else if (total || summary) {
    if (failed || mismatch) {
      tone = "failed";
      title = "status=apply-problem";
      detail = `${failed + mismatch} 项写入失败或未粘住，优先查看下方问题列表。`;
    } else if (!hasSettled) {
      tone = "mismatch";
      title = "status=partial-apply";
      detail = "apply.log 存在，但没有 settled 阶段；请确认已刷入最新包并开机等待至少 3 分钟。";
    } else if (diagnosticState.postApplyOverrides.length && !diagnosticState.unresolved.length && !diagnosticState.missing.length) {
      tone = "mismatch";
      title = "status=post-apply-override";
      detail = `apply.log 已写入成功，但 ${diagnosticState.postApplyOverrides.length} 项最终 getprop 被系统后置覆盖。`;
    } else if (diagnosticState.mismatches.length || diagnosticState.missing.length) {
      tone = "mismatch";
      title = "status=needs-follow-up";
      detail = `${diagnosticState.mismatches.length + diagnosticState.missing.length} 项最终 getprop 与 system.prop 不一致，需要回传完整诊断。`;
    } else {
      tone = "applied";
      title = "status=ok";
      detail = "initial/recheck/settled 均已记录，system.prop 启用项与最终 getprop 一致，且 apply.log 未发现失败项。";
    }
  }

  conclusion.classList.add(tone);
  conclusion.append(createElement("strong", "", title));
  conclusion.append(createElement("span", "", latestPass ? `${detail} 最新阶段：${latestPass.phase}` : detail));
  return conclusion;
}

function createDiagnosticChip(label, value, tone) {
  const chip = createElement("span", `diagnostic-chip ${tone}`);
  chip.append(createElement("strong", "", String(value)));
  chip.append(createElement("small", "", label));
  return chip;
}

function showDialog(title, content, beforeContent, options = {}) {
  const dialog = createElement("div", "dialog");
  const saveButton = options.savePath ? '<button class="text-button" data-action="save">保存</button>' : "";
  dialog.innerHTML = `
    <div class="dialog-panel">
      <div class="section-title">
        <h2>${escapeHtml(title)}</h2>
        <div class="dialog-actions">
          ${saveButton}
          <button class="text-button" data-action="copy">${escapeHtml(options.copyLabel || "复制")}</button>
          <button class="text-button" data-action="close">关闭</button>
        </div>
      </div>
      <pre></pre>
    </div>
  `;
  if (beforeContent) {
    dialog.querySelector("pre").before(beforeContent);
  }
  const pre = dialog.querySelector("pre");
  pre.textContent = content;
  dialog.querySelector('[data-action="close"]').addEventListener("click", () => dialog.remove());
  dialog.querySelector('[data-action="copy"]').addEventListener("click", () => copyDialogContent(content, pre));
  dialog.querySelector('[data-action="save"]')?.addEventListener("click", () => saveDialogContent(content, options.savePath));
  document.body.append(dialog);
}

async function saveDialogContent(content, savePath) {
  const result = await writeBase64(savePath, content);

  if (result.code === 0) {
    setStatus(`已保存到 ${savePath}`, "ok");
  } else {
    setStatus(`保存失败：${result.stderr || result.stdout || result.code}`, "warn");
  }
}

async function copyDialogContent(content, pre) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(content);
      setStatus("内容已复制", "ok");
      return;
    }
  } catch {
    // Fall back to selecting the text so WebUI hosts without clipboard support remain usable.
  }

  const range = document.createRange();
  range.selectNodeContents(pre);
  const selection = globalThis.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  setStatus("已选中文本，请手动复制", "warn");
}

async function rebootDevice() {
  const ok = showConfirm("确定现在重启设备吗？");
  if (!ok) return;
  setStatus("正在请求重启...");
  const result = await exec("reboot");
  if (result.code !== 0) {
    setStatus(`重启失败：${resultMessage(result)}`, "warn");
  }
}

async function openUrl(url) {
  if (!url) {
    setStatus("链接还没有填写", "warn");
    return;
  }
  let quotedUrl;
  try {
    quotedUrl = commandUrl(url);
  } catch (error) {
    setStatus(`链接无效：${error.message}`, "warn");
    return;
  }

  const result = await exec(`am start -a android.intent.action.VIEW -d ${quotedUrl}`);
  if (result.code !== 0) {
    console.warn(`[dex2oat] openUrl failed: ${result.stderr || result.stdout}`);
    setStatus(`打开链接失败：${resultMessage(result)}`, "warn");
  }
}

async function start() {
  state.meta = await loadMeta();
  state.unifiedState = await loadUnifiedState();
  state.device = await loadDeviceState();
  state.configSource = await loadConfigSource();
  state.health = await loadHealthState();
  state.options = await loadOptionsForDevice(state.device);
  state.config = await loadUserConfig(state.options);

  renderShell();
  setPage("home");
  await refreshAll();
}

start().catch((error) => {
  const app = $("#app");
  if (app) {
    app.innerHTML = "";
    const screen = createElement("main", "boot-screen");
    screen.append(createElement("h1", "", "Dex2oat Lock"));
    screen.append(createElement("p", "", `WebUI 初始化失败：${error.message}`));
    app.append(screen);
  }
});
